﻿using CMCS.Models;
using CMCS.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CMCS.Controllers
{
    public class LecturerController : Controller
    {
        private readonly InMemoryDataService _dataService;
        private readonly FileEncryptionService _encryptionService;

        public LecturerController(InMemoryDataService dataService, FileEncryptionService encryptionService)
        {
            _dataService = dataService;
            _encryptionService = encryptionService;
        }

        // GET: Lecturer Dashboard
        public IActionResult Dashboard()
        {
            try
            {
                // For demo purposes, we'll use the first lecturer
                // In real app, this would come from authentication
                var lecturer = _dataService.GetAllLecturers().FirstOrDefault();

                if (lecturer == null)
                {
                    TempData["ErrorMessage"] = "No lecturer profile found.";
                    return RedirectToAction("Index", "Home");
                }

                ViewBag.LecturerName = lecturer.FullName;
                ViewBag.LecturerId = lecturer.LecturerId;

                var claims = _dataService.GetClaimsByLecturer(lecturer.LecturerId);
                return View(claims);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading dashboard: {ex.Message}";
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Lecturer/SubmitClaim
        public IActionResult SubmitClaim()
        {
            try
            {
                var lecturers = _dataService.GetAllLecturers();
                ViewBag.Lecturers = new SelectList(lecturers, "LecturerId", "FullName");

                // Generate month options (last 6 months)
                var months = new List<SelectListItem>();
                for (int i = 0; i < 6; i++)
                {
                    var date = DateTime.Now.AddMonths(-i);
                    months.Add(new SelectListItem
                    {
                        Value = date.ToString("yyyy-MM"),
                        Text = date.ToString("MMMM yyyy")
                    });
                }
                ViewBag.Months = months;

                return View(new Claim());
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading claim form: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }

        // POST: Lecturer/SubmitClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitClaim(Claim claim, IFormFileCollection documents)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    // Reload dropdown data
                    var lecturers = _dataService.GetAllLecturers();
                    ViewBag.Lecturers = new SelectList(lecturers, "LecturerId", "FullName");

                    var months = new List<SelectListItem>();
                    for (int i = 0; i < 6; i++)
                    {
                        var date = DateTime.Now.AddMonths(-i);
                        months.Add(new SelectListItem
                        {
                            Value = date.ToString("yyyy-MM"),
                            Text = date.ToString("MMMM yyyy")
                        });
                    }
                    ViewBag.Months = months;

                    TempData["ErrorMessage"] = "Please correct the errors and try again.";
                    return View(claim);
                }

                // Get lecturer name
                var lecturer = _dataService.GetLecturerById(claim.LecturerId);
                if (lecturer == null)
                {
                    ModelState.AddModelError("", "Invalid lecturer selected.");
                    return View(claim);
                }

                claim.LecturerName = lecturer.FullName;

                // Get hourly rate from contract
                if (lecturer.ContractId.HasValue)
                {
                    var contract = _dataService.GetContractById(lecturer.ContractId.Value);
                    if (contract != null)
                    {
                        claim.HourlyRate = contract.HourlyRate;
                    }
                }

                // Calculate total amount
                claim.CalculateTotalAmount();

                // Add claim to data service
                var addedClaim = _dataService.AddClaim(claim);

                // Handle file uploads
                if (documents != null && documents.Count > 0)
                {
                    foreach (var file in documents)
                    {
                        if (file.Length > 0)
                        {
                            // Validate file type
                            if (!_encryptionService.IsValidFileType(file.FileName))
                            {
                                TempData["WarningMessage"] = $"File '{file.FileName}' was skipped. Only PDF, DOCX, and XLSX files are allowed.";
                                continue;
                            }

                            // Validate file size
                            if (!_encryptionService.IsValidFileSize(file.Length))
                            {
                                TempData["WarningMessage"] = $"File '{file.FileName}' was skipped. Maximum file size is 5MB.";
                                continue;
                            }

                            // Read file content
                            using (var memoryStream = new System.IO.MemoryStream())
                            {
                                await file.CopyToAsync(memoryStream);
                                var fileBytes = memoryStream.ToArray();

                                // Encrypt file content
                                var encryptedContent = _encryptionService.EncryptFile(fileBytes);

                                // Create document record
                                var document = new SupportingDocument
                                {
                                    ClaimId = addedClaim.ClaimId,
                                    FileName = file.FileName,
                                    FilePath = $"encrypted_{addedClaim.ClaimId}_{file.FileName}",
                                    FileSizeKB = file.Length / 1024,
                                    EncryptedContent = encryptedContent
                                };

                                _dataService.AddDocument(document);
                            }
                        }
                    }
                }

                TempData["SuccessMessage"] = $"Claim submitted successfully! Claim ID: {addedClaim.ClaimId}";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error submitting claim: {ex.Message}";
                return View(claim);
            }
        }

        // GET: Lecturer/ViewClaim/5
        public IActionResult ViewClaim(int id)
        {
            try
            {
                var claim = _dataService.GetClaimById(id);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Get supporting documents
                var documents = _dataService.GetDocumentsByClaim(id);
                ViewBag.Documents = documents;

                // Get approvals
                var approvals = _dataService.GetApprovalsByClaim(id);
                ViewBag.Approvals = approvals;

                return View(claim);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading claim: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }

        // GET: Lecturer/DownloadDocument/5
        public IActionResult DownloadDocument(int id)
        {
            try
            {
                var document = _dataService.GetDocumentById(id);
                if (document == null)
                {
                    TempData["ErrorMessage"] = "Document not found.";
                    return RedirectToAction("Dashboard");
                }

                // Decrypt file content
                var decryptedContent = _encryptionService.DecryptFile(document.EncryptedContent);

                // Determine content type based on file extension
                string contentType = "application/octet-stream";
                string extension = System.IO.Path.GetExtension(document.FileName).ToLower();

                if (extension == ".pdf")
                    contentType = "application/pdf";
                else if (extension == ".docx")
                    contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                else if (extension == ".xlsx")
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                return File(decryptedContent, contentType, document.FileName);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error downloading document: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }
    }
}