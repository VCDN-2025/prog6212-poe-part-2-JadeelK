﻿using CMCS.Models;
using CMCS.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace CMCS.Controllers
{
    public class ManagerController : Controller
    {
        private readonly InMemoryDataService _dataService;
        private readonly FileEncryptionService _encryptionService;

        public ManagerController(InMemoryDataService dataService, FileEncryptionService encryptionService)
        {
            _dataService = dataService;
            _encryptionService = encryptionService;
        }

        // GET: Manager Dashboard
        public IActionResult Dashboard()
        {
            try
            {
                // Get all verified claims (pending final approval)
                var verifiedClaims = _dataService.GetClaimsByStatus("Verified");

                ViewBag.ManagerName = "Jane Manager"; // In real app, from authentication
                ViewBag.VerifiedCount = verifiedClaims.Count;
                ViewBag.TotalApproved = _dataService.GetApprovedClaimsCount();
                ViewBag.TotalRejected = _dataService.GetRejectedClaimsCount();

                return View(verifiedClaims);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading dashboard: {ex.Message}";
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Manager/ReviewClaim/5
        public IActionResult ReviewClaim(int id)
        {
            try
            {
                var claim = _dataService.GetClaimById(id);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Get supporting documents
                var documents = _dataService.GetDocumentsByClaim(id);
                ViewBag.Documents = documents;

                // Get all approvals (including coordinator's)
                var approvals = _dataService.GetApprovalsByClaim(id);
                ViewBag.Approvals = approvals;

                return View(claim);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading claim: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }

        // POST: Manager/ApproveClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ApproveClaim(int claimId, string comments)
        {
            try
            {
                var claim = _dataService.GetClaimById(claimId);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Update claim status to Approved
                _dataService.UpdateClaimStatus(claimId, "Approved");

                // Add approval record
                var approval = new Approval
                {
                    ClaimId = claimId,
                    UserId = 2, // Manager user ID
                    ApproverName = "Jane Manager",
                    Role = "Manager",
                    Decision = "Approved",
                    Comments = string.IsNullOrWhiteSpace(comments) ? "Approved for payment" : comments
                };

                _dataService.AddApproval(approval);

                TempData["SuccessMessage"] = $"Claim #{claimId} has been approved successfully.";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error approving claim: {ex.Message}";
                return RedirectToAction("ReviewClaim", new { id = claimId });
            }
        }

        // POST: Manager/RejectClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RejectClaim(int claimId, string comments)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(comments))
                {
                    TempData["ErrorMessage"] = "Please provide a reason for rejection.";
                    return RedirectToAction("ReviewClaim", new { id = claimId });
                }

                var claim = _dataService.GetClaimById(claimId);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Update claim status to Rejected
                _dataService.UpdateClaimStatus(claimId, "Rejected");

                // Add approval record
                var approval = new Approval
                {
                    ClaimId = claimId,
                    UserId = 2,
                    ApproverName = "Jane Manager",
                    Role = "Manager",
                    Decision = "Rejected",
                    Comments = comments
                };

                _dataService.AddApproval(approval);

                TempData["SuccessMessage"] = $"Claim #{claimId} has been rejected.";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error rejecting claim: {ex.Message}";
                return RedirectToAction("ReviewClaim", new { id = claimId });
            }
        }

        // GET: Manager/DownloadDocument/5
        public IActionResult DownloadDocument(int id)
        {
            try
            {
                var document = _dataService.GetDocumentById(id);
                if (document == null)
                {
                    TempData["ErrorMessage"] = "Document not found.";
                    return RedirectToAction("Dashboard");
                }

                // Decrypt file content
                var decryptedContent = _encryptionService.DecryptFile(document.EncryptedContent);

                // Determine content type
                string contentType = "application/octet-stream";
                string extension = System.IO.Path.GetExtension(document.FileName).ToLower();

                if (extension == ".pdf")
                    contentType = "application/pdf";
                else if (extension == ".docx")
                    contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                else if (extension == ".xlsx")
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                return File(decryptedContent, contentType, document.FileName);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error downloading document: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }

        // GET: Manager/AllClaims (View all claims with statistics)
        public IActionResult AllClaims()
        {
            try
            {
                var allClaims = _dataService.GetAllClaims();

                ViewBag.TotalClaims = allClaims.Count;
                ViewBag.PendingClaims = _dataService.GetPendingClaimsCount();
                ViewBag.VerifiedClaims = _dataService.GetVerifiedClaimsCount();
                ViewBag.ApprovedClaims = _dataService.GetApprovedClaimsCount();
                ViewBag.RejectedClaims = _dataService.GetRejectedClaimsCount();

                return View(allClaims);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading claims: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }
    }
}