﻿using CMCS.Models;
using CMCS.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace CMCS.Controllers
{
    public class CoordinatorController : Controller
    {
        private readonly InMemoryDataService _dataService;
        private readonly FileEncryptionService _encryptionService;

        public CoordinatorController(InMemoryDataService dataService, FileEncryptionService encryptionService)
        {
            _dataService = dataService;
            _encryptionService = encryptionService;
        }

        // GET: Coordinator Dashboard
        public IActionResult Dashboard()
        {
            try
            {
                // Get all submitted claims (pending verification)
                var pendingClaims = _dataService.GetClaimsByStatus("Submitted");

                ViewBag.CoordinatorName = "John Coordinator"; // In real app, from authentication
                ViewBag.PendingCount = pendingClaims.Count;

                return View(pendingClaims);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading dashboard: {ex.Message}";
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Coordinator/ReviewClaim/5
        public IActionResult ReviewClaim(int id)
        {
            try
            {
                var claim = _dataService.GetClaimById(id);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Get supporting documents
                var documents = _dataService.GetDocumentsByClaim(id);
                ViewBag.Documents = documents;

                // Get existing approvals
                var approvals = _dataService.GetApprovalsByClaim(id);
                ViewBag.Approvals = approvals;

                return View(claim);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error loading claim: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }

        // POST: Coordinator/VerifyClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VerifyClaim(int claimId, string comments)
        {
            try
            {
                var claim = _dataService.GetClaimById(claimId);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Update claim status to Verified
                _dataService.UpdateClaimStatus(claimId, "Verified");

                // Add approval record
                var approval = new Approval
                {
                    ClaimId = claimId,
                    UserId = 1, // Coordinator user ID (from Users list)
                    ApproverName = "John Coordinator",
                    Role = "Coordinator",
                    Decision = "Verified",
                    Comments = string.IsNullOrWhiteSpace(comments) ? "Verified by coordinator" : comments
                };

                _dataService.AddApproval(approval);

                TempData["SuccessMessage"] = $"Claim #{claimId} has been verified successfully.";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error verifying claim: {ex.Message}";
                return RedirectToAction("ReviewClaim", new { id = claimId });
            }
        }

        // POST: Coordinator/RejectClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RejectClaim(int claimId, string comments)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(comments))
                {
                    TempData["ErrorMessage"] = "Please provide a reason for rejection.";
                    return RedirectToAction("ReviewClaim", new { id = claimId });
                }

                var claim = _dataService.GetClaimById(claimId);
                if (claim == null)
                {
                    TempData["ErrorMessage"] = "Claim not found.";
                    return RedirectToAction("Dashboard");
                }

                // Update claim status to Rejected
                _dataService.UpdateClaimStatus(claimId, "Rejected");

                // Add approval record
                var approval = new Approval
                {
                    ClaimId = claimId,
                    UserId = 1,
                    ApproverName = "John Coordinator",
                    Role = "Coordinator",
                    Decision = "Rejected",
                    Comments = comments
                };

                _dataService.AddApproval(approval);

                TempData["SuccessMessage"] = $"Claim #{claimId} has been rejected.";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error rejecting claim: {ex.Message}";
                return RedirectToAction("ReviewClaim", new { id = claimId });
            }
        }

        // GET: Coordinator/DownloadDocument/5
        public IActionResult DownloadDocument(int id)
        {
            try
            {
                var document = _dataService.GetDocumentById(id);
                if (document == null)
                {
                    TempData["ErrorMessage"] = "Document not found.";
                    return RedirectToAction("Dashboard");
                }

                // Decrypt file content
                var decryptedContent = _encryptionService.DecryptFile(document.EncryptedContent);

                // Determine content type
                string contentType = "application/octet-stream";
                string extension = System.IO.Path.GetExtension(document.FileName).ToLower();

                if (extension == ".pdf")
                    contentType = "application/pdf";
                else if (extension == ".docx")
                    contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                else if (extension == ".xlsx")
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                return File(decryptedContent, contentType, document.FileName);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error downloading document: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }
    }
}