﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class Approval
    {
        public int ApprovalId { get; set; }

        public int ClaimId { get; set; }

        public int UserId { get; set; }

        [Display(Name = "Approver Name")]
        public string ApproverName { get; set; }

        [Display(Name = "Role")]
        public string Role { get; set; } // "Coordinator" or "Manager"

        [Display(Name = "Decision")]
        public string Decision { get; set; } // "Approved", "Rejected", "Verified"

        [Display(Name = "Comments")]
        [DataType(DataType.MultilineText)]
        public string Comments { get; set; }

        [Display(Name = "Decided At")]
        public DateTime? DecidedAt { get; set; }
    }
}