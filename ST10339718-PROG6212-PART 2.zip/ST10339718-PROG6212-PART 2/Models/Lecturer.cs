﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class Lecturer
    {
        [Key]
        public int LecturerId { get; set; }

        [Required, MaxLength(200)]
        public string FullName { get; set; }

        [MaxLength(200)]
        public string Email { get; set; }

        [MaxLength(50)]
        public string Phone { get; set; }

        // Foreign key to Contract (optional)
        public int? ContractId { get; set; }
        public Contract Contract { get; set; }

        // Navigation
        public ICollection<Claim> Claims { get; set; } = new List<Claim>();
    }
}
