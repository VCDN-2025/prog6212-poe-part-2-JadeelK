﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class Contract
    {
        [Key]
        public int ContractId { get; set; }

        [DataType(DataType.Currency)]
        public decimal HourlyRate { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}