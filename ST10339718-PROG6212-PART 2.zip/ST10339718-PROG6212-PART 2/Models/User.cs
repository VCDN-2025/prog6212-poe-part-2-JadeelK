﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required, MaxLength(200)]
        public string FullName { get; set; }

        [MaxLength(200)]
        public string Email { get; set; }

        [MaxLength(50)]
        public string Role { get; set; } // "Coordinator", "Manager"

        public ICollection<Approval> Approvals { get; set; } = new List<Approval>();
    }
}
