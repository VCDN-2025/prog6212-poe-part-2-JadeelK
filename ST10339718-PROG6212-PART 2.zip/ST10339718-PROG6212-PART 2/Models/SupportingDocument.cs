﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class SupportingDocument
    {
        public int DocId { get; set; }

        public int ClaimId { get; set; }

        [Display(Name = "File Name")]
        public string FileName { get; set; }

        [Display(Name = "File Path")]
        public string FilePath { get; set; }

        [Display(Name = "Uploaded At")]
        public DateTime UploadedAt { get; set; }

        [Display(Name = "File Size (KB)")]
        public long FileSizeKB { get; set; }

        // Encrypted file content (stored in memory)
        public byte[] EncryptedContent { get; set; }
    }
}