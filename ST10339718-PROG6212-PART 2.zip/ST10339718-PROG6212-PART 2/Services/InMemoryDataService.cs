﻿using CMCS.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMCS.Services
{
    public class InMemoryDataService
    {
        // In-memory storage
        private static List<Lecturer> _lecturers = new List<Lecturer>();
        private static List<Claim> _claims = new List<Claim>();
        private static List<SupportingDocument> _documents = new List<SupportingDocument>();
        private static List<Approval> _approvals = new List<Approval>();
        private static List<User> _users = new List<User>();
        private static List<Contract> _contracts = new List<Contract>();

        // ID counters
        private static int _nextClaimId = 1;
        private static int _nextDocId = 1;
        private static int _nextApprovalId = 1;
        private static int _nextLecturerId = 1;
        private static int _nextUserId = 1;
        private static int _nextContractId = 1;

        public InMemoryDataService()
        {
            InitializeData();
        }

        private void InitializeData()
        {
            // Only initialize if empty
            if (_lecturers.Count == 0)
            {
                // Initialize Contracts
                _contracts = new List<Contract>
                {
                    new Contract { ContractId = _nextContractId++, HourlyRate = 350.00M, StartDate = new DateTime(2025, 1, 1), EndDate = new DateTime(2025, 12, 31) },
                    new Contract { ContractId = _nextContractId++, HourlyRate = 420.00M, StartDate = new DateTime(2025, 1, 1), EndDate = new DateTime(2025, 12, 31) },
                    new Contract { ContractId = _nextContractId++, HourlyRate = 380.00M, StartDate = new DateTime(2025, 1, 1), EndDate = new DateTime(2025, 12, 31) }
                };

                // Initialize Lecturers
                _lecturers = new List<Lecturer>
                {
                    new Lecturer { LecturerId = _nextLecturerId++, FullName = "Dr. Sarah Johnson", Email = "sarah.j@university.ac.za", Phone = "0821234567", ContractId = 1 },
                    new Lecturer { LecturerId = _nextLecturerId++, FullName = "Prof. Michael Chen", Email = "michael.c@university.ac.za", Phone = "0827654321", ContractId = 2 },
                    new Lecturer { LecturerId = _nextLecturerId++, FullName = "Dr. Amina Patel", Email = "amina.p@university.ac.za", Phone = "0829876543", ContractId = 3 }
                };

                // Initialize Users (Coordinators and Managers)
                _users = new List<User>
                {
                    new User { UserId = _nextUserId++, FullName = "John Coordinator", Email = "john.coord@university.ac.za", Role = "Coordinator" },
                    new User { UserId = _nextUserId++, FullName = "Jane Manager", Email = "jane.mgr@university.ac.za", Role = "Manager" }
                };

                // Initialize sample claims
                _claims = new List<Claim>
                {
                    new Claim
                    {
                        ClaimId = _nextClaimId++,
                        LecturerId = 1,
                        LecturerName = "Dr. Sarah Johnson",
                        PeriodMonth = "2025-09",
                        HoursWorked = 120,
                        HourlyRate = 350.00M,
                        TotalAmount = 42000.00M,
                        Status = "Submitted",
                        SubmittedAt = DateTime.Now.AddDays(-5),
                        Notes = "Programming lectures for September"
                    },
                    new Claim
                    {
                        ClaimId = _nextClaimId++,
                        LecturerId = 2,
                        LecturerName = "Prof. Michael Chen",
                        PeriodMonth = "2025-08",
                        HoursWorked = 100,
                        HourlyRate = 420.00M,
                        TotalAmount = 42000.00M,
                        Status = "Verified",
                        SubmittedAt = DateTime.Now.AddDays(-10),
                        Notes = "Database Systems course"
                    }
                };
            }
        }

        // ===== CLAIM METHODS =====
        public List<Claim> GetAllClaims() => _claims;

        public List<Claim> GetClaimsByLecturer(int lecturerId) =>
            _claims.Where(c => c.LecturerId == lecturerId).OrderByDescending(c => c.SubmittedAt).ToList();

        public List<Claim> GetClaimsByStatus(string status) =>
            _claims.Where(c => c.Status == status).OrderByDescending(c => c.SubmittedAt).ToList();

        public Claim GetClaimById(int claimId) => _claims.FirstOrDefault(c => c.ClaimId == claimId);

        public Claim AddClaim(Claim claim)
        {
            claim.ClaimId = _nextClaimId++;
            claim.SubmittedAt = DateTime.Now;
            claim.Status = "Submitted";
            claim.CalculateTotalAmount();
            _claims.Add(claim);
            return claim;
        }

        public bool UpdateClaimStatus(int claimId, string newStatus)
        {
            var claim = GetClaimById(claimId);
            if (claim != null)
            {
                claim.Status = newStatus;
                return true;
            }
            return false;
        }

        // ===== LECTURER METHODS =====
        public List<Lecturer> GetAllLecturers() => _lecturers;

        public Lecturer GetLecturerById(int lecturerId) => _lecturers.FirstOrDefault(l => l.LecturerId == lecturerId);

        // ===== DOCUMENT METHODS =====
        public List<SupportingDocument> GetDocumentsByClaim(int claimId) =>
            _documents.Where(d => d.ClaimId == claimId).ToList();

        public SupportingDocument AddDocument(SupportingDocument document)
        {
            document.DocId = _nextDocId++;
            document.UploadedAt = DateTime.Now;
            _documents.Add(document);
            return document;
        }

        public SupportingDocument GetDocumentById(int docId) =>
            _documents.FirstOrDefault(d => d.DocId == docId);

        // ===== APPROVAL METHODS =====
        public List<Approval> GetApprovalsByClaim(int claimId) =>
            _approvals.Where(a => a.ClaimId == claimId).OrderBy(a => a.DecidedAt).ToList();

        public Approval AddApproval(Approval approval)
        {
            approval.ApprovalId = _nextApprovalId++;
            approval.DecidedAt = DateTime.Now;
            _approvals.Add(approval);
            return approval;
        }

        // ===== USER METHODS =====
        public List<User> GetAllUsers() => _users;

        public User GetUserById(int userId) => _users.FirstOrDefault(u => u.UserId == userId);

        // ===== CONTRACT METHODS =====
        public Contract GetContractById(int contractId) =>
            _contracts.FirstOrDefault(c => c.ContractId == contractId);

        // ===== STATISTICS =====
        public int GetPendingClaimsCount() => _claims.Count(c => c.Status == "Submitted");

        public int GetVerifiedClaimsCount() => _claims.Count(c => c.Status == "Verified");

        public int GetApprovedClaimsCount() => _claims.Count(c => c.Status == "Approved");

        public int GetRejectedClaimsCount() => _claims.Count(c => c.Status == "Rejected");
    }
}