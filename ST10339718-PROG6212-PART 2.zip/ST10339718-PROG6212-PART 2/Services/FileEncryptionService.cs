﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CMCS.Services
{
    public class FileEncryptionService
    {
        // Fixed encryption key (32 bytes for AES-256)
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("CMCS2025SecureKey!@#$%^&*()12");
        // Fixed IV (16 bytes for AES)
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("CMCS2025InitVec!");

        /// <summary>
        /// Encrypts file content using AES encryption
        /// </summary>
        public byte[] EncryptFile(byte[] fileContent)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = Key;
                    aes.IV = IV;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                    using (MemoryStream msEncrypt = new MemoryStream())
                    {
                        using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            csEncrypt.Write(fileContent, 0, fileContent.Length);
                            csEncrypt.FlushFinalBlock();
                        }
                        return msEncrypt.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Encryption failed: {ex.Message}");
            }
        }

        /// <summary>
        /// Decrypts file content using AES decryption
        /// </summary>
        public byte[] DecryptFile(byte[] encryptedContent)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = Key;
                    aes.IV = IV;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                    using (MemoryStream msDecrypt = new MemoryStream(encryptedContent))
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    using (MemoryStream msPlain = new MemoryStream())
                    {
                        csDecrypt.CopyTo(msPlain);
                        return msPlain.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Decryption failed: {ex.Message}");
            }
        }

        /// <summary>
        /// Validates file type (only pdf, docx, xlsx allowed)
        /// </summary>
        public bool IsValidFileType(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                return false;

            string extension = Path.GetExtension(fileName).ToLower();
            return extension == ".pdf" || extension == ".docx" || extension == ".xlsx";
        }

        /// <summary>
        /// Validates file size (max 5MB)
        /// </summary>
        public bool IsValidFileSize(long fileSizeBytes)
        {
            const long maxSizeBytes = 5 * 1024 * 1024; // 5MB
            return fileSizeBytes > 0 && fileSizeBytes <= maxSizeBytes;
        }
    }
}